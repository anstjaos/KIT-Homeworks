#include "Person.h"

Person :: Person(string p_name, string p_department, string p_phoneNumber)
{
	name = p_name;
	department = p_department;
	phoneNumber = p_phoneNumber;
}