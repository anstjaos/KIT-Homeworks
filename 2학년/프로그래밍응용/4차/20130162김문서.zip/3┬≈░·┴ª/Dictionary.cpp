#include "Dictionary.h"

Dictionary:: Dictionary(int i_number, string i_word, string i_definition)
{
	number = i_number;
	word = i_word;
	definition = i_definition;
}