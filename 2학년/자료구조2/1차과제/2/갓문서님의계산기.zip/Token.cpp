#include "Token.h"

Token :: Token(token i_data, int i_type)
{
	data = i_data;
	type = i_type;
}