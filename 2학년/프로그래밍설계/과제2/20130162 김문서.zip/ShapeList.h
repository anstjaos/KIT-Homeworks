#pragma once
#include "Circle.h"

class ShapeList {
private:
	Shape* s_list[10];
	int count;
public:
	ShapeList() { count = 0;}
	~ShapeList();

	int getCount() { return count; }
	Shape* getShape(int index) { return s_list[index]; }

	int findIndex(string id);
	void sortList(int left, int right);
	void insertShape(Shape* s);
	void deleteShape(int index);
};