#pragma once
#include <iostream>
#include <string>

enum Menu{ INSERT =1, DELETE, DISPLAY, EXIT};
using namespace std;

class Shape {
private:
	double defineDistance();
protected:
	string id;
	int x;
	int y;
	double area;
	double distance;
	double perimeter;
public:
	Shape() {}
	Shape(int i_x, int i_y);
	virtual ~Shape() {}

	virtual string getId() { return id; }
	virtual int getX() { return x; }
	virtual int getY() { return y; }
	virtual double getArea() { return area; }
	virtual double getDistance() { return distance; }
	virtual double getPerimeter() { return perimeter; }
	virtual double getRadius() { return 0; };

	virtual string defineID(int count) { return ""; }
	virtual void putShape() {}
};