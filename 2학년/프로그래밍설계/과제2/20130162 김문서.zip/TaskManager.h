#pragma once
#include "ShapeList.h"

class TaskManager {
public:
	void insertShape(ShapeList &sl);
	void deleteShape(ShapeList &sl);
	void displayShape(ShapeList &sl);
};