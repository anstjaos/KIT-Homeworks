#pragma once
#include "Shape.h"

class Circle : public Shape{
private:
	double radius;
public:
	Circle(int count, int i_x, int i_y, double i_radius);
	~Circle() {}

	string defineID(int count);
	double getRadius() { return radius;}

	void putShape();
};
