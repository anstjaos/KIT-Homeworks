#include "Shape.h"

Shape ::Shape(int i_x, int i_y)
{
	x = i_x;
	y = i_y;
	distance = defineDistance();
} 

double Shape::defineDistance()
{
	double num = (x*x) + (y*y);
	double temp;
	double next = 0.5 * (1 + num);

	while (1)
	{
		temp = next;
		next = 0.5 * (next + (num / next));

		if (temp - next < 0.005 || temp - next < -0.005) break;
	}
	return next;
}