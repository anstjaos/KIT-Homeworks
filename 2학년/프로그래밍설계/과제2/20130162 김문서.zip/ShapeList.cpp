#include "ShapeList.h"

ShapeList ::~ShapeList()
{
	for (int i = 0; i < count; i++)
	{
		delete s_list[i];
	}
}

int ShapeList::findIndex(string id)
{
	int index = -1;
	for (int i = 0; i < count; i++)
	{
		if (s_list[i]->getId() == id)
		{
			index = i;
			break;
		}
	}
	return index;
}

void ShapeList::sortList(int left, int right)
{
	int leftIndex = left;
	int rightIndex = right;
	double pivot = s_list[(left + right) / 2]->getDistance();

	while (leftIndex <= rightIndex)
	{
		while (s_list[leftIndex]->getDistance() < pivot) leftIndex++;
		while (s_list[rightIndex]->getDistance() > pivot) rightIndex--;

		if (leftIndex <= rightIndex)
		{
			swap(s_list[leftIndex], s_list[rightIndex]);
			leftIndex++;
			rightIndex--;
		}
	}

	if (left < rightIndex) sortList(left, rightIndex);
	if (right > leftIndex) sortList(leftIndex, right);
}

void ShapeList ::insertShape(Shape* s)
{
	s_list[count++] = s;
}

void ShapeList ::deleteShape(int index)
{
	delete s_list[index];
	s_list[index] = s_list[count - 1];
	count--;
}