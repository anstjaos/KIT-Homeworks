#include "Circle.h"

Circle::Circle(int count, int i_x, int i_y, double i_radius) : Shape(i_x, i_y)
{
	id = defineID(count);
	radius = i_radius;
	area = radius * radius * 3.14;
	perimeter = 2 * 3.14 * radius;
}

string Circle ::defineID(int count)
{
	string result = "C";

	if (count < 10)
	{
		result = result + "0" + to_string(count);
	}
	else result = result + to_string(count);

	return result;
}

void Circle::putShape()
{
	cout << getId() << "\t" << getX() << "," << getY() << "\t\t" << getRadius() << "\t";
	cout << getArea() << "\t" << getPerimeter() << "\t" << getDistance() << endl;
}