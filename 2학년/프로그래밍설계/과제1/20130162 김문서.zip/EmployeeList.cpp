#include "EmployeeList.h"

EmployeeList::EmployeeList()
{
	count = 0;
}

int EmployeeList::getCount()
{
	return count;
}

Employee EmployeeList::getEmployee(int index)
{
	return empList[index];
}

void EmployeeList ::insertEmployee(Employee e)
{
	empList[count++] = e;
}
