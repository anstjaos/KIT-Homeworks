#include "Employee.h"

Employee::Employee(string i_name, string i_department, int index)
{
	name = i_name;
	department = i_department;
	employeeNum = defineNum(index);
}
string Employee ::defineNum(int index)
{
	if (index == 0) return "0001";

	index++;
	int cnt = 0;
	int temp = index;
	while (temp != 0)
	{
		temp = temp / 10;
		cnt++;
	}

	string result = "";
	for (int i = 4; i > cnt; i--)
	{
		result = result + '0';
	}

	result = result + to_string(index);
	return result;
}

string Employee::getName()
{
	return name;
}

string Employee::getDepartment()
{
	return department;
}

string Employee::getEmployeeNum()
{
	return employeeNum;
}