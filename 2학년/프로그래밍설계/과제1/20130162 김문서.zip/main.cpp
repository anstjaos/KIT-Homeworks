#include "TaskManager.h"

void main()
{
	TaskManager tm;
	tm.run();
}