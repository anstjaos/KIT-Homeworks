#pragma once
#include "Employee.h"

class EmployeeList {
private:
	Employee empList[10];
	int count;
public:
	EmployeeList();
	~EmployeeList() {}

	int getCount();
	Employee getEmployee(int index);

	void insertEmployee(Employee e);
};