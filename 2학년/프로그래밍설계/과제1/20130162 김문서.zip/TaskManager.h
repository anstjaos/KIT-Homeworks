#pragma once
#include "EmployeeList.h"

class TaskManager {
private:
	EmployeeList el;

	void insertEmployee(int num);
	void showEmployee(int num);
public:
	void run();
};