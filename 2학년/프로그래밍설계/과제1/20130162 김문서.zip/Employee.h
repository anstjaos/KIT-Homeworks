#pragma once
#include <iostream>
#include <string>
#include <iomanip>
using namespace std;

class Employee {
private:
	string name;
	string department;
	string employeeNum;

	string defineNum(int index);
public:
	Employee() {}
	Employee(string i_name, string i_department, int index);
	~Employee() {}

	string getName();
	string getDepartment();
	string getEmployeeNum();
};