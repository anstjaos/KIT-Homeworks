package Online_bank;

public interface ControllerInterface {
	public void execute();
}
