package Online_bank;

public interface Observer {
	public void update();
}
