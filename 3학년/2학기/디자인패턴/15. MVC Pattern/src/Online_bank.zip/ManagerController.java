package Online_bank;

public class ManagerController implements ControllerInterface{
	private ManagerView managerView;
	
	public ManagerController() {
		managerView = new ManagerView();
	}
	
	public void execute() {
		
	}
}
