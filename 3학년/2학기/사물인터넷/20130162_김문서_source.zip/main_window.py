# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'mainwindow.ui'
#
# Created by: PyQt5 UI code generator 5.7
#
# WARNING! All changes made in this file will be lost!

import pymysql
import RPi.GPIO as GPIO
import boto3
from PyQt5 import QtCore, QtGui, QtWidgets
from picamera import PiCamera
from register_window import Ui_Form
from login_window import LoginWindow
from userinfo import UserInfo

GPIO.setmode(GPIO.BCM)
GPIO.setup(17, GPIO.IN, GPIO.PUD_UP)
s3 = boto3.client('s3')
client = boto3.client('rekognition')

class Ui_MainWindow(object):
    def check_user(self, uid):
        conn = pymysql.connect(host='54.82.120.60', port=3306, user='root', password='anstj0177',db='mvc_pattern', charset='utf8')
        curs = conn.cursor()
        
        try:
            sql = 'select * from users where id = %s'
            curs.execute(sql,(uid))
            if curs.rowcount > 0:
                return False
            else:
                return True
        finally:
            conn.close()
        
    def insert_user(self, uid, pwd, name):
        conn = pymysql.connect(host='54.82.120.60', port=3306, user='root', password='anstj0177',db='mvc_pattern', charset='utf8')
        curs = conn.cursor()
        
        try:
            sql = 'insert into users (id,password,name) values (%s, %s, %s)'
            curs.execute(sql,(uid,pwd,name))
            conn.commit()
            print(curs.lastrowid)
        finally:
            conn.close()

    def upload_image(self, uid):
        bucket = "anstjaos"
        obj = uid+".jpg"
        local_file_path = "face.jpg"
        s3.upload_file(local_file_path, bucket, obj)
        
    def show_messagebox(self, title, msg):
        msgbox = QtWidgets.QMessageBox(MainWindow)
        msgbox.setText(msg)
        msgbox.setWindowTitle(title)
        msgbox.setStandardButtons(QtWidgets.QMessageBox.Ok)
        msgbox.show()

    def capture_image(self):
        camera.start_preview()
        GPIO.wait_for_edge(17, GPIO.FALLING)
        camera.capture('/home/pi/IoT_FaceLogin/face.jpg')
        camera.stop_preview()
        
    def register_user(self):
        uid = self.ui.idEdit.text()
        pwd = self.ui.pwdEdit.text()
        name = self.ui.nameEdit.text()

        if len(uid) == 0 or len(pwd) == 0 or len(name) == 0:
            self.show_messagebox("Failed!", "Empty Input!")
            return
        if self.check_user(uid) == False:
            self.show_messagebox("Failed!", "Id is already exist!")
            return

        self.capture_image()
        self.insert_user(uid, pwd, name)
        self.upload_image(uid)
        self.show_messagebox("Sucess", "Register Sucess!")
        self.window.hide()
        MainWindow.show()

    def authentication(self, uid, pwd):
        conn = pymysql.connect(host='54.82.120.60', port=3306, user='root', password='anstj0177',db='mvc_pattern', charset='utf8')
        curs = conn.cursor()
        
        try:
            sql = 'select * from users where id = %s and password = %s'
            curs.execute(sql,(uid, pwd))
            if curs.rowcount > 0:
                return True
            else:
                return False
        finally:
            conn.close()

    def face_check(self, uid):
        bucket = "anstjaos"
        obj = uid+".jpg"
        s3.download_file(bucket, obj, obj)

        imageSource=open(obj,'rb')
        imageTarget=open('face.jpg','rb')
    
        response=client.compare_faces(SimilarityThreshold=70,
                                      SourceImage={'Bytes': imageSource.read()},
                                      TargetImage={'Bytes': imageTarget.read()})

        confidence = 0
        for faceMatch in response['FaceMatches']:
            confidence = faceMatch['Face']['Confidence']
        
        imageSource.close()
        imageTarget.close()
        print(confidence)
        if confidence >= 90.0:
            return True
        else:
            return False
        
    def login_user(self):
        uid = self.idEdit.text()
        pwd = self.pwdEdit.text()

        if len(uid) == 0 or len(pwd) == 0:
            self.show_messagebox("Failed!", "Empty Input!")
            return
        
        if self.authentication(uid, pwd) == False:
            self.show_messagebox("Login Failed!", "Unknown User!")
            return

        self.capture_image()
        if self.face_check(uid) == True:
            self.show_messagebox("Login", "Login Sucess!")
            self.openLoginWindow(uid)
        else:
            self.show_messagebox("Login", "Login Failed!")

    def update(self, uid, pwd, name):
        conn = pymysql.connect(host='54.82.120.60', port=3306, user='root', password='anstj0177',db='mvc_pattern', charset='utf8')
        curs = conn.cursor()
        try:
            sql = 'update users set password = %s, name = %s where id = %s'
            curs.execute(sql,(pwd,name,uid))
            conn.commit()
            print(curs.lastrowid)
        finally:
            conn.close()
        
    def update_user(self):
        uid = self.info_ui.uidLabel.text()
        pwd = self.info_ui.pwdEdit.text()
        name = self.info_ui.nameEdit.text()
    
        if len(pwd) == 0 or len(name) == 0:
            self.show_messagebox("Failed!", "Empty Input!")
            return
        
        self.capture_image()
        self.update(uid, pwd, name)
        self.upload_image(uid)
        self.show_messagebox("Sucess", "Update Sucess!")
        pixmap = QtGui.QPixmap('face.jpg')
        pixmap = pixmap.scaled(300,250, QtCore.Qt.KeepAspectRatio)
        self.login_ui.pictureLabel.setPixmap(pixmap)
        self.open_login()

    def withdraw(self, uid):
        conn = pymysql.connect(host='54.82.120.60', port=3306, user='root', password='anstj0177',db='mvc_pattern', charset='utf8')
        curs = conn.cursor()
        try:
            sql = 'delete from users where id = %s'
            curs.execute(sql,(uid))
            conn.commit()
            print(curs.lastrowid)
        finally:
            conn.close()
            
    def withdraw_user(self,uid):
        self.withdraw(uid)
        
        file_name = uid+'.jpg'
        bucket = 'anstjaos'
        s3.delete_object(Bucket=bucket, Key=file_name)
        
        self.show_messagebox("Success", "WIthdraw User Sucess!")
        self.login_window.hide()
        MainWindow.show()
        
    def withdrawUser(self, uid):
        def withdraw():
            reply = QtWidgets.QMessageBox.question(MainWindow, "Withdraw Msg", "Do you want withdraw?", QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No)
            if reply == QtWidgets.QMessageBox.Yes:
                self.withdraw_user(uid)
        return withdraw
        
    def closeWindow(self):
        sys.exit(0)
    
    def openMainWindow(self):
        self.window.hide()
        MainWindow.show()
        
    def openWIndow(self):
        self.window = QtWidgets.QWidget()
        self.ui = Ui_Form() 
        self.ui.setupUi(self.window)
        MainWindow.hide()
        self.ui.cancelBtn.clicked.connect(self.openMainWindow)
        self.ui.OKbtn.clicked.connect(self.register_user)
        self.window.show()

    def openUserInfo(self,uid):
        def show_userinfo(): 
            self.login_window.hide()
            self.info_window = QtWidgets.QWidget()
            self.info_ui = UserInfo() 
            self.info_ui.setupUi(self.info_window)

            self.info_ui.uidLabel.setText(uid)
            self.info_ui.okBtn.clicked.connect(self.update_user)
            self.info_ui.cancelBtn.clicked.connect(self.open_login)
            self.info_window.show()
        return show_userinfo
        
    def openLoginWindow(self, uid):
        self.login_window = QtWidgets.QWidget()
        self.login_ui = LoginWindow()
        self.login_ui.setupUi(self.login_window)
        MainWindow.hide()

        self.login_ui.uidLabel.setText(uid)
        pixmap = QtGui.QPixmap(uid+'.jpg')
        pixmap = pixmap.scaled(300,250, QtCore.Qt.KeepAspectRatio)
        self.login_ui.pictureLabel.setPixmap(pixmap)
        self.login_ui.updateBtn.clicked.connect(self.openUserInfo(uid))
        self.login_ui.withdrawBtn.clicked.connect(self.withdrawUser(uid))
        self.login_window.show()

    def open_login(self):
        self.info_window.hide()
        self.login_window.show()
        
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(400, 300)
        self.centralWidget = QtWidgets.QWidget(MainWindow)
        self.centralWidget.setObjectName("centralWidget")
        self.loginBtn = QtWidgets.QPushButton(self.centralWidget)
        self.loginBtn.setGeometry(QtCore.QRect(20, 200, 85, 31))
        self.loginBtn.setObjectName("loginBtn")
        self.loginBtn.clicked.connect(self.login_user)
        
        self.cancelBtn = QtWidgets.QPushButton(self.centralWidget)
        self.cancelBtn.setGeometry(QtCore.QRect(139, 200, 85, 31))
        self.cancelBtn.setObjectName("cancelBtn")
        self.cancelBtn.clicked.connect(self.closeWindow)
        
        self.registerBtn = QtWidgets.QPushButton(self.centralWidget)
        self.registerBtn.setGeometry(QtCore.QRect(258, 200, 101, 31))
        self.registerBtn.setObjectName("registerBtn")
        self.registerBtn.clicked.connect(self.openWIndow)
        
        self.IDLabel = QtWidgets.QLabel(self.centralWidget)
        self.IDLabel.setGeometry(QtCore.QRect(21, 51, 15, 21))
        self.IDLabel.setObjectName("IDLabel")
        self.pwdLabel = QtWidgets.QLabel(self.centralWidget)
        self.pwdLabel.setGeometry(QtCore.QRect(21, 110, 70, 21))
        self.pwdLabel.setObjectName("pwdLabel")
        self.idEdit = QtWidgets.QLineEdit(self.centralWidget)
        self.idEdit.setGeometry(QtCore.QRect(130, 50, 231, 30))
        self.idEdit.setObjectName("idEdit")
        self.pwdEdit = QtWidgets.QLineEdit(self.centralWidget)
        self.pwdEdit.setGeometry(QtCore.QRect(130, 110, 231, 30))
        self.pwdEdit.setEchoMode(QtWidgets.QLineEdit.Password)
        self.pwdEdit.setObjectName("pwdEdit")
        self.loginBtn.raise_()
        self.cancelBtn.raise_()
        self.registerBtn.raise_()
        self.IDLabel.raise_()
        self.pwdLabel.raise_()
        self.idEdit.raise_()
        self.pwdEdit.raise_()
        MainWindow.setCentralWidget(self.centralWidget)
        self.menuBar = QtWidgets.QMenuBar(MainWindow)
        self.menuBar.setGeometry(QtCore.QRect(0, 0, 400, 27))
        self.menuBar.setObjectName("menuBar")
        MainWindow.setMenuBar(self.menuBar)
        self.mainToolBar = QtWidgets.QToolBar(MainWindow)
        self.mainToolBar.setObjectName("mainToolBar")
        MainWindow.addToolBar(QtCore.Qt.TopToolBarArea, self.mainToolBar)
        self.statusBar = QtWidgets.QStatusBar(MainWindow)
        self.statusBar.setObjectName("statusBar")
        MainWindow.setStatusBar(self.statusBar)
        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "Face Check Login"))
        self.loginBtn.setText(_translate("MainWindow", "Login"))
        self.cancelBtn.setText(_translate("MainWindow", "Cancel"))
        self.registerBtn.setText(_translate("MainWindow", "Register"))
        self.IDLabel.setText(_translate("MainWindow", "ID"))
        self.pwdLabel.setText(_translate("MainWindow", "Password"))


if __name__ == "__main__":
    camera = PiCamera()
    import sys
    app = QtWidgets.QApplication(sys.argv)
    MainWindow = QtWidgets.QMainWindow()
    ui = Ui_MainWindow()
    ui.setupUi(MainWindow)
    MainWindow.show()
    sys.exit(app.exec_())

