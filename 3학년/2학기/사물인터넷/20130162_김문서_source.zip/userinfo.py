# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'userinfo.ui'
#
# Created by: PyQt5 UI code generator 5.7
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class UserInfo(object):
    def setupUi(self, Form):
        Form.setObjectName("Form")
        Form.resize(400, 300)
        self.idLabel = QtWidgets.QLabel(Form)
        self.idLabel.setGeometry(QtCore.QRect(20, 60, 15, 21))
        self.idLabel.setObjectName("idLabel")
        self.pwdLabel = QtWidgets.QLabel(Form)
        self.pwdLabel.setGeometry(QtCore.QRect(20, 130, 70, 21))
        self.pwdLabel.setObjectName("pwdLabel")
        self.nameLabel = QtWidgets.QLabel(Form)
        self.nameLabel.setGeometry(QtCore.QRect(20, 200, 42, 21))
        self.nameLabel.setObjectName("nameLabel")
        self.pwdEdit = QtWidgets.QLineEdit(Form)
        self.pwdEdit.setGeometry(QtCore.QRect(131, 120, 191, 33))
        self.pwdEdit.setObjectName("pwdEdit")
        self.nameEdit = QtWidgets.QLineEdit(Form)
        self.nameEdit.setGeometry(QtCore.QRect(131, 200, 191, 33))
        self.nameEdit.setObjectName("nameEdit")
        self.okBtn = QtWidgets.QPushButton(Form)
        self.okBtn.setGeometry(QtCore.QRect(120, 260, 101, 31))
        self.okBtn.setObjectName("okBtn")
        self.cancelBtn = QtWidgets.QPushButton(Form)
        self.cancelBtn.setGeometry(QtCore.QRect(250, 260, 101, 31))
        self.cancelBtn.setObjectName("cancelBtn")
        self.uidLabel = QtWidgets.QLabel(Form)
        self.uidLabel.setGeometry(QtCore.QRect(130, 60, 191, 21))
        self.uidLabel.setText("")
        self.uidLabel.setObjectName("uidLabel")

        self.retranslateUi(Form)
        QtCore.QMetaObject.connectSlotsByName(Form)

    def retranslateUi(self, Form):
        _translate = QtCore.QCoreApplication.translate
        Form.setWindowTitle(_translate("Form", "Form"))
        self.idLabel.setText(_translate("Form", "ID"))
        self.pwdLabel.setText(_translate("Form", "Password"))
        self.nameLabel.setText(_translate("Form", "Name"))
        self.okBtn.setText(_translate("Form", "OK"))
        self.cancelBtn.setText(_translate("Form", "Cancel"))


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    Form = QtWidgets.QWidget()
    ui = UserInfo()
    ui.setupUi(Form)
    Form.show()
    sys.exit(app.exec_())

