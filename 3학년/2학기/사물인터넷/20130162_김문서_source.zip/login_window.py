# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'loginwindow.ui'
#
# Created by: PyQt5 UI code generator 5.7
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class LoginWindow(object):
    def setupUi(self, Form):
        Form.setObjectName("Form")
        Form.resize(400, 300)
        self.updateBtn = QtWidgets.QPushButton(Form)
        self.updateBtn.setGeometry(QtCore.QRect(41, 251, 101, 31))
        self.updateBtn.setObjectName("updateBtn")
        self.withdrawBtn = QtWidgets.QPushButton(Form)
        self.withdrawBtn.setGeometry(QtCore.QRect(240, 251, 101, 31))
        self.withdrawBtn.setObjectName("withdrawBtn")
        self.pictureLabel = QtWidgets.QLabel(Form)
        self.pictureLabel.setGeometry(QtCore.QRect(50, 50, 291, 171))
        self.pictureLabel.setAutoFillBackground(False)
        self.pictureLabel.setText("")
        self.pictureLabel.setObjectName("pictureLabel")
        
        self.uidLabel = QtWidgets.QLabel(Form)
        self.uidLabel.setGeometry(QtCore.QRect(0,0,0,0))
        self.uidLabel.setAutoFillBackground(False)
        self.uidLabel.setText("")
        self.uidLabel.setObjectName("uidLabel")

        self.retranslateUi(Form)
        QtCore.QMetaObject.connectSlotsByName(Form)

    def retranslateUi(self, Form):
        _translate = QtCore.QCoreApplication.translate
        Form.setWindowTitle(_translate("Form", "Form"))
        self.updateBtn.setText(_translate("Form", "Update Info"))
        self.withdrawBtn.setText(_translate("Form", "Withdrawl"))


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    Form = QtWidgets.QWidget()
    ui = LoginWindow()
    ui.setupUi(Form)
    Form.show()
    sys.exit(app.exec_())

