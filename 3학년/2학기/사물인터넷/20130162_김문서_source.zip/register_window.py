# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'registerwindow.ui'
#
# Created by: PyQt5 UI code generator 5.7
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets
#from main_window import Ui_MainWindow

class Ui_Form(object):
   # def openWindow(self):
     #   self.window = QtWidgets.QMainWindow()
     #   self.ui = Ui_MainWindow()
      #  self.ui.setupUi(self.window)
     #   Form.hide()
     #   self.window.show()
        
    def setupUi(self, Form):
        Form.setObjectName("Form")
        Form.resize(400, 300)
        self.OKbtn = QtWidgets.QPushButton(Form)
        self.OKbtn.setGeometry(QtCore.QRect(151, 251, 101, 31))
        self.OKbtn.setObjectName("OKbtn")
        
        self.cancelBtn = QtWidgets.QPushButton(Form)
        self.cancelBtn.setGeometry(QtCore.QRect(280, 251, 101, 31))
        self.cancelBtn.setObjectName("cancelBtn")
       # self.cancelBtn.clicked.connect(self.openWindow)
        
        self.idLabel = QtWidgets.QLabel(Form)
        self.idLabel.setGeometry(QtCore.QRect(11, 41, 16, 21))
        self.idLabel.setObjectName("idLabel")
        self.pwdLabel = QtWidgets.QLabel(Form)
        self.pwdLabel.setGeometry(QtCore.QRect(11, 110, 70, 21))
        self.pwdLabel.setObjectName("pwdLabel")
        self.nameLabel = QtWidgets.QLabel(Form)
        self.nameLabel.setGeometry(QtCore.QRect(11, 180, 42, 21))
        self.nameLabel.setObjectName("nameLabel")
        self.idEdit = QtWidgets.QLineEdit(Form)
        self.idEdit.setGeometry(QtCore.QRect(131, 41, 181, 33))
        self.idEdit.setObjectName("idEdit")
        self.pwdEdit = QtWidgets.QLineEdit(Form)
        self.pwdEdit.setGeometry(QtCore.QRect(131, 110, 181, 33))
        self.pwdEdit.setEchoMode(QtWidgets.QLineEdit.Password)
        self.pwdEdit.setObjectName("pwdEdit")
        self.nameEdit = QtWidgets.QLineEdit(Form)
        self.nameEdit.setGeometry(QtCore.QRect(131, 180, 181, 33))
        self.nameEdit.setObjectName("nameEdit")

        self.retranslateUi(Form)
        QtCore.QMetaObject.connectSlotsByName(Form)

    def retranslateUi(self, Form):
        _translate = QtCore.QCoreApplication.translate
        Form.setWindowTitle(_translate("Form", "Form"))
        self.OKbtn.setText(_translate("Form", "OK"))
        self.cancelBtn.setText(_translate("Form", "Cancel"))
        self.idLabel.setText(_translate("Form", "ID"))
        self.pwdLabel.setText(_translate("Form", "Password"))
        self.nameLabel.setText(_translate("Form", "Name"))


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    Form = QtWidgets.QWidget()
    ui = Ui_Form()
    ui.setupUi(Form)
    Form.show()
    sys.exit(app.exec_())

